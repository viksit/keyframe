**To delete an interconnect**

The following ``delete-interconnect`` command deletes the specified interconnect::

  aws directconnect delete-interconnect --interconnect-id dxcon-fgktov66

Output::

  {
      "interconnectState": "deleted"
  }